document.getElementById("ver_Fzrvv").addEventListener('submit', function(event) {
         event.preventDefault();
    
          var username = document.getElementById('username').value;
         var password = document.getElementById('password').value;
         var errorMessage = document.getElementById('error-message');
    
      if (username === '' || password ==='') {
             errorMessage.textContent = 'ISI USERNAME DAN PASSWORD.';
      } else if (username !== "Maritsun" || password !=='VioletDetector165') {
          errorMessage.textContent = 'USERNAME ATAU PASSWORD SALAH. MOHON COBA LAGI.'
      } else {
         errorMessage.textContent = ''
         alert('LOGIN SUKSES.');
      }
    
   });